import os
import pickle
import pandas as pd

class Cache:
    def __init__(self, cache_dir: str = "__cache__"):
        self.cache_dir = cache_dir

        # Create the cache directory if it does not exist
        if not os.path.exists(self.cache_dir):
            os.mkdir(self.cache_dir)
        
    def get(self, key: str) -> object:
        # Check if the file exists
        if os.path.exists(f"{self.cache_dir}/{key}.pkl"):
            return pd.read_pickle(f"{self.cache_dir}/{key}.pkl")
        else:
            return None

    def set(self, key: str, value: object):
        pickle.dump(value, open(f"{self.cache_dir}/{key}.pkl", "wb"))

    def delete(self, key: str):
        os.remove(f"{self.cache_dir}/{key}.pkl")

    def clear(self):
        for file in os.listdir(self.cache_dir):
            os.remove(f"{self.cache_dir}/{file}")