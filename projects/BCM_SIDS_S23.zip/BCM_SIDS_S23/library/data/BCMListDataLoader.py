"""
BCMDataLoader Module
====
Load the data

"""

# Add the library folder to the path
from collections import defaultdict
import gzip
import funcy
import tqdm as tqdm
from dotenv import load_dotenv
import os
from boxsdk import Client
import re
from library.box.auth import authenticate
import sys
import pandas as pd
import numpy as np
import pickle
from contextlib import nullcontext
from library.data.Cache import Cache

sys.path.append('../')


load_dotenv()


class BCMListDataLoader:
    def __init__(self, data_dir: str = "data", client: Client = None, overwrite: bool = False, verbose: bool = False):
        # Ensure that the data folder exists otherwise throw an error
        if not os.path.exists(data_dir):
            raise ValueError(f"Data folder {data_dir} does not exist")

        self.data_dir = data_dir
        self.verbose = verbose

        self.client = client
        if client is None:
            oauth, access_token, _ = authenticate()
            self.access_token = access_token
            client = Client(oauth)

        # Give the shared link to the client
        s_client: Client = client.with_shared_link(
            os.getenv("BCM_SHARED_LINK"), None)

        self.client = s_client

        self.cache = Cache(f"{self.data_dir}/__cache__")
        if overwrite:
            self.cache.clear()

        self.__get_list_files__()
        self.__get_metadata_files__()
    
    def refresh_oauth(self):
        if self.access_token is None:
            print("No access token found, skipping refresh")
            return

        oauth = self.client.auth

        # Refresh the access token
        access_token, refresh_token = oauth.refresh(self.access_token)
        self.access_token = access_token


    # You can (and probably should?) make the next 5 funcs into a single func that takes the 
    # env variable key as a parameter
    def __get_list_files__(self):
        print("Getting list files...") if self.verbose else None

        # Check if they are in the cache
        self.files = self.cache.get("list_files")
        if self.files is not None:
            print("Found list files in cache") if self.verbose else None
            return

        # Get the `pklgzip` folder
        folder_id = os.getenv("BCM_LIST_FOLDER_ID")
        folder = self.client.folder(folder_id=folder_id)

        # Get all the items in the folder
        items = [item for item in folder.get_items(limit=1000)]
        self.files = defaultdict(list)
        for file in items:
            # Get the mid from the file name
            mid = get_mid(file.name)
            suffix = "breath" if ("breath" in file.name) else "beat"

            if mid:
                # Add the file to the dictionary
                self.files[f"{mid}_{suffix}"].append(file.id)

        self.files = dict(self.files)   
        
        # Save to cache
        self.cache.set("list_files", self.files)

        print(f"Found {len(self.files)} files") if self.verbose else None

    def __get_metadata_files__(self):
        print("Getting metadata files...") if self.verbose else None

        # Check if they are in the cache
        self.meta_data_files = self.cache.get("metadata_files")
        if self.meta_data_files is not None:
            print("Found metadata files in cache") if self.verbose else None
            return

        folder_id = os.getenv("BCM_METADATA_FOLDER_ID")
        folder = self.client.folder(folder_id=folder_id)

        self.meta_data_files = {
            get_mid(item.name): item.id
            for item in folder.get_items(limit=1000)
        }

    def __download_list_file__(self, mid: str, overwrite: bool = False, type: str = "breath"):
        # Ensure that the mid is in the list of files
        if (f"{mid}_{type}") not in self.files:
            raise ValueError(f"File for {mid}, {type} not found")
        
        # Get the file ids
        file_ids = self.files[mid + "_" + type]

        if not overwrite:
            # Don't download files that already exist
            if os.path.exists(f"{self.data_dir}/{mid}_{type}.pkl.gz"):
                print(f"Skipping data {mid} because it already exists") if self.verbose else None
                return pd.read_pickle(f"{self.data_dir}/{mid}_{type}.pkl.gz", compression="gzip")
        
        # Download the files and set the largest file to the file path
        files = []
        for i, file_id in enumerate(file_ids):
            box_file = self.client.file(file_id)
            cur_file_path = f"{self.data_dir}/{mid}_{type}-{file_id}.csv"

            # Download the file using a writable stream and progress bar
            print(f"{i} / {len(file_id)}\t| Downloading {mid} {type} data...") if self.verbose else None
            with open(cur_file_path, "wb") as f:
                b: bytes = box_file.content()

                # Chunk the bytes using funcy
                chunks = funcy.chunks(1024, b)

                # Create a progress bar
                with tqdm.tqdm(total=len(b), unit='B', unit_scale=True, desc=f"Writing {mid} {type} data to file.") if self.verbose else nullcontext() as pbar:
                    for chunk in chunks:
                        f.write(chunk)
                        pbar.update(len(chunk)) if self.verbose else None

            files.append({
                "path": cur_file_path,
                "size": os.path.getsize(cur_file_path)
            })

        # Sort the files by size
        files = sorted(files, key=lambda x: x["size"], reverse=True)

        # Set the file path to the largest file
        file_path = files[0]["path"]

        # Read the file to a pandas dataframe, first col is the index
        df = pd.read_csv(file_path, index_col=0 if type == "breath" else None)

        # Rename the time col to correspond with the needed col
        df = df.rename(columns={"Timestamp_Inspiration" if type == "breath" else "ts": "time"})
        
        # Save the dataframe to a pickle file
        df.to_pickle(f"{self.data_dir}/{mid}_{type}.pkl.gz", compression="gzip")

        # Delete the other files
        for file in files:
            os.remove(file["path"])

        # Return the pickle file
        return df
    
    def __download_metadata_file__(self, mid: str, overwrite: bool = False):
        print(f"Downloading Metadata for {mid}...") if self.verbose else None
        if mid not in self.meta_data_files:
            print(f"Unable to label {mid} because it does not have metadata") if self.verbose else None
            return
        
        file_id = self.meta_data_files[mid]

        if not overwrite:
            # Don't download files that already exist
            if os.path.exists(f"{self.data_dir}/{mid}_metadata.csv"):
                print(f"Skipping downloading metadata for {mid} because it already exists") if self.verbose else None
                return pd.read_csv(f"{self.data_dir}/{mid}_metadata.csv")
        
        box_file = self.client.file(file_id)
        file_path = f"{self.data_dir}/{mid}.xlsx"

        with open(file_path, "wb") as f:
            f.write(box_file.content())

            timestamps = pd.read_excel(file_path, sheet_name="Timestamps")

            timestamps.to_pickle(f"{self.data_dir}/{mid}_metadata.pkl")

            os.remove(file_path)

            return timestamps

    
    def __process_data__(self, data: pd.DataFrame, metadata: pd.DataFrame, type: str = "breath"):
        cond = []
        choices = []
        for i, row in metadata.iterrows():
            if i < len(metadata) - 1:
                cond.append((data["time"] >= row["ts"]) & (data["time"] < metadata.iloc[i + 1]["ts"]))
                choices.append(row["text"])
            else:
                cond.append(data["time"] >= row["ts"])
                choices.append(row["text"])

        data["sub_mode_block"] = np.select(cond, choices, default="")

        # Remove the parameter column if it exists
        if "parameter" in data.columns:
            data = data.drop(columns=["parameter"])

        # Add the weight and genotype columns from the metadata
        data["weight"] = metadata.iloc[0]["Weight"]
        data["genotype"] = metadata.iloc[0]["Genotype"]

        # ----------------------------------------------
        # CHANGE HERE FOR ALTERING THE OBSERVATION SEGMENTATION
        # ----------------------------------------------

        # Segment the data into observation numbers, an observation is denoted 
        # when the sub_mode_block column changes from recovery to anoxic.

        # Get the indices where the sub_mode_block column changes to Anoxic
        anoxic_indices = data[(data["sub_mode_block"].shift(
        ) != data["sub_mode_block"]) & (data["sub_mode_block"] == "Anoxic")].index

        # Get the indices where the sub_mode_block column changes to Recovery
        recovery_indices = data[(data["sub_mode_block"].shift(
        ) != data["sub_mode_block"]) & (data["sub_mode_block"] == "Recovery")].index

        # Create a sorted list of the indices
        indices = sorted(anoxic_indices.tolist() + recovery_indices.tolist())

        # Add the observation id column and set to 1 where mode_block is Challege
        data["observation_id"] = None

        # Set the observation number for each observation
        for i, index in enumerate(anoxic_indices):
            # Get the start and end time of the observation
            data.loc[index:, "observation_start"] = data.loc[index, "time"]
            data.loc[index:, "observation_end"] = data.loc[anoxic_indices[i + 1], "time"] if i < len(anoxic_indices) - 1 else data.loc[index, "time"]

            data.loc[index:, "observation_id"] = i + 1

        # Set the sub_mode_block_id based on the indices
        data["sub_mode_block_id"] = None
        for i, index in enumerate(indices):
            # Get the start and end time of the sub_mode_block
            data.loc[index:, "sub_mode_block_start"] = data.loc[index, "time"]
            data.loc[index:, "sub_mode_block_end"] = data.loc[indices[i + 1], "time"] if i < len(indices) - 1 else data.loc[index, "time"]

            # Check if the data at index + 1 is anoxic or recovery
            data.loc[index:, "sub_mode_block_id"] = f"Anoxic-{i}" if data.loc[index , "sub_mode_block"] == "Anoxic" else f"Recovery-{i}"

        return data
    
    def download_mids(self, mids: list, overwrite: bool = False, type: str = "breath"):
        # If mids is not a set make it a set
        if not isinstance(mids, set):
            mids = set(mids)

        data_dict = {}
        # Download all of the files
        for mid in tqdm.tqdm(mids):
            data_dict[mid] = self.get(mid, overwrite=overwrite, type=type)
            
        return data_dict
    
    def get(self, file_name: str, overwrite: bool = False, type: str = "breath"):
        # Check if the file exists
        mid, type = file_name.split("_")

        if os.path.exists(f"{self.data_dir}/{mid}_{type}.pkl.gz") and not overwrite:
            return pd.read_pickle(f"{self.data_dir}/{mid}_{type}.pkl.gz")
        
        # Download the file
        metadata = self.__download_metadata_file__(mid)
        if metadata is None:
            print(f"Unable to process data for {mid} because it does not have metadata")
            return None

        data = self.__download_list_file__(mid, type=type)

        # Process the data
        print(f"Processing {mid} {type}...") if self.verbose else None
        processed_data = self.__process_data__(data, metadata, type=type)

        # Save the processed data
        processed_data.to_pickle(f"{self.data_dir}/{mid}_{type}.pkl.gz", compression="gzip")

        return processed_data


    # Iteration methods
    def __iter__(self):
        for mid in self.files.keys():
            yield mid

    def __len__(self):
        return len(self.files)

    def __next__(self):
        if self.current < len(self):
            self.current += 1
            return self.get(self.files[self.current], overwrite=True)
        else:
            raise StopIteration


def get_mid(item_name):
    mid = re.search(r'[R|r]\d+', item_name)
    if mid:
        return mid.group(0)
    else:
        # Return everything before .pkl.gzip
        return None