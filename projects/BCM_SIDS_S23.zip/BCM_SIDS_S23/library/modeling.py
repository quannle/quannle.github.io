import sys
import pandas as pd
import numpy as np
from mrmr import mrmr_regression
from sklearn.model_selection import train_test_split, cross_validate

def clean_data(df, threshold, verbose=False):
    """
    Drops rows with more than <threshold> NA values.

    Arguments:
        df: pandas dataframe
        threshold: the number of NA values permitted
        verbose: verbosity of function
    """

    # get rid of NA values
    data = df.dropna(axis=1, thresh=len(df)-threshold)
    null_columns = set(df.columns).difference(data.columns)
    print(f"dropped {len(null_columns)} columns with more than {threshold} NA values")
    frame = data.dropna(axis=0, how="any")
    print(f"removed {len(data) - len(frame)} rows with NA values")

    # set hierarchical index
    frame = frame.set_index(keys=["mid", "observation_id"]) 

    # remove non numeric columns
    odd_types = []
    for c in frame.columns:
        type = frame[c].dtype
        if type == np.object:
            odd_types.append(c)
            if verbose:
                print(f"{c:<30}: {type}")
    frame = frame.drop(labels=odd_types, axis=1)

    return frame



def remove_time_dependent_columns(df):
    """"
    Removes highly corellated features and returns tuple of dataframes for modeling.

    Arguments:
        df: pandas dataframe
    """
    y = df["ttd"] 
    x = df.drop(axis=1, labels=[
        "ttd", 
        "observation_id_x",
        "observation_id_y",
        "observation_end",
        "observation_end_x",
        "observation_end_y",
        "observation_start",
        "observation_start_x",
        "observation_start_y",
        "il_exhale",
        "il_end",
        "ts_end",
        "sub_mode_block_id",
        "sub_mode_block_start",
        "sub_mode_block_start_x",
        "sub_mode_block_start_y",
        "sub_mode_block_end",
        "sub_mode_block_end_x",
        "sub_mode_block_end_y",
        "Breath Number",
        "Timestamp_Expiration",
        "time_x",
        "time_y"
        ])
    return x, y



def get_null_count(df, verbose=False):
    """
    Gets the nuber of null values for each feature.

    Arguments:
        df: pandas dataframe
        verbose: verbosity of function
    """
    null_count = {}
    for c in df.columns:
        null_count[c] = sum(df[c].isna())
        if null_count[c] > 0:
            print(f"{c:<30}: {null_count[c]}")
    return null_count


def mrmr(x, y, k):
    """
    Select the k top scoring features, given x and y.

    Arguments:
        x: a dataframe of predictors
        y: response variable
        k: number of features to select
    """
    features, relevance, redundancy = mrmr_regression(x, y, K=k, return_scores=True)

    selected = []
    not_selected = list(features)
    scores = np.empty(len(features))
    for i in range(len(features)):
        score = relevance.loc[not_selected] / redundancy.loc[not_selected, selected].mean(axis = 1).fillna(.00001)
        scores[i] = score.max()
        best = score.index[score.argmax()]
        selected.append(best)
        not_selected.remove(best)

    return features, scores


def tester(model, x_train, x_test, y_train, y_test, scoring, verbose=False):
    """
    Evaluate a model, given training and testing data.

    Arguments:
        model: model to evaluate
        x_train: training predictors
        x_test: test set of predictors
        y_train: training set response
        y_test: test set response
        scoring: scoring method for cross validation
        verbose: verbosity of function
    """

    fitted = model.fit(x_train, y_train)
    cv = cross_validate(fitted, x_train, y_train, cv=10, scoring=scoring)
    score = np.mean(cv['test_score'])
    if verbose:
        print(f"{model.__class__.__name__ : <30} & {score:.2f} \\\\")
    # plt.scatter(y, model.predict(x))
    fitted = model.fit(x_train, y_train)
    residuals = y_test - fitted.predict(x_test)
    residuals = np.abs(residuals)
    # plt.scatter(y_test, residuals)

    result = {"cv_score":   cv["test_score"],
              "residuals":  residuals,
              "yhat":       fitted}

    return result


def wrapper(args):
    return tester(*args)




