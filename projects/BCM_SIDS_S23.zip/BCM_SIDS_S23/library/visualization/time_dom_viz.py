"""
The module for visualizing data in time domain
"""

# Rely packages 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.misc import electrocardiogram
from scipy import signal
from scipy.fft import fftshift
from pylab import *
import adi
from matplotlib.widgets import Slider


# Functions
def plot_signal(data, timestamps, title, breath_flag=True): 
    """
    Given data and timestamps for a signal, plot the signal over the given time period. 

    Inputs: 
    ----------
    data (ls or ndarray): The observations from the signal
    timestamps (ls or ndarray): Timestamps which the data was recorded at. len(data) 
                                must equal len(timestamps)
    title (str): The title to be used for the plot

    Optional
    breath_flag: True if the data is breathing data, False for ECG data. The default is True. 

    Outputs: 
    ----------
    Returns nothing. Instead, displays the created plot. 
    """
    plt.plot(timestamps, data)

    plt.xlabel("Timestamps (s)")
    if breath_flag: 
        plt.ylabel("Breathing Volume Signal Amplitude (mL/min)")
    else:
        plt.ylabel("ECG Signal Amplitude (mV)")
    plt.title(title)
    
    
    
def viz_labchart_file(filename,
                     start_tick=0,
                     end_tick=-1):
    """
    Plots all channels of the Labchart (.adicht)
    file in the timewindow of interest (the default
    is all time points).
    
    Inputs:
    ----------
    filename (str): the name of the Labchart file    
    
    Optional:
    start_tick (int): starting time for plots
                      according to comments (
                      output of read_labchart_file)
                      e.g., start_tick = 529349
                      for mouse M21264 is after
                      CNO injection. 
    end_tick (int):   final time for plots.
    The default is [0:-1] plots all datapoints.
    
    Outputs:
    -------
    The function does not have outputs,
    it only plots the data for viz of the file content.
    Use read_labchart_file to read-in signals.
    
    """
    
    # Read the labchart file
    adi_file = adi.read_file(filename)
    
    # Plot each channel in the file
    for channel_id in range(adi_file.n_channels):
        
        # Signal record in the chosen time window:
        signal = adi_file.channels[channel_id].get_data(1)[start_tick:end_tick]
        
        # Time record (start with zero)
        time_tick = adi_file.channels[channel_id].dt[0]  
        n_samples =  len(signal)
        timestep = np.arange(0, n_samples*time_tick, time_tick) 
        
        # Plot timeseries
        plt.figure(figsize=(20,6))
        plt.plot(timestep, signal)
        
        # Channel name as the plot title
        plt.title(adi_file.channels[channel_id].name)
        
        # Axes names
        plt.xlabel('Time (s)')
        plt.ylabel(adi_file.channels[channel_id].units[0])
        
        plt.show()
        
    return None




def min_max_normalize(signal):
    
    """
    Normalizes signal in range 0-1.
    The function is usefull when comparing
    different in amplitude/baseline signals 
    (e.g., plot on the same y-scale).
    
    Input:
    ----------
    signal (ndarray): the signal data to normalize    
    
    Output:
    -------
    normalized_signal (ndarray): min-max normalized
                                 signal (0-1 range)
    
    """
    
    normalized_signal = (signal - min(signal)) /   \
                        ( max(signal) - min(signal) )
    
    return normalized_signal




def viz_filtering_with_sliderplot(signal, 
                                  filtered_signal,
                                  timestep,
                                  normalization=False,
                                  ampl_min=-0.5,
                                  ampl_max=0.3,
                                  label1='Signal',
                                  label2='Filtered signal',
                                  plot_title='Signal before and after filtering',
                                 ):
    """
    Plot raw and filtered signals on 
    the slider plot for comparison.
    
    Inputs:
    ----------
    signal (ndarray):          the raw signal
    filtered_signal (ndarray): the filtered signal
                               (e.g., output of the 
                                breathing_filter 
                                function)
    timestep (ndarray):        time points
    
    Optional:
    normalization (bool): min-max normalization of
                          signals if needed.
                          The default is False.
    ampl_min (int):       ylim for signal display
    ampl_max (int):       ylim for signal display
    label1, label2 (str): legend labels for displayed
                          signals
    plot_title (str):     plot title label
    
    
    Output:
    -------
    The function does not have outputs,
    it only plots the data for viz of the two signals.
    
    """
    
    # Optional: normalize signals
    # for plotting on the similar y-scale
    if normalization:
        signal = min_max_normalize(signal)
        filtered_signal = min_max_normalize(filtered_signal)
    
    # Allocate space for the slider
    fig, ax = plt.subplots()
    plt.subplots_adjust(bottom=0.25)
    
    # Plot timeseries as lines 1 and 2
    line1, = plt.plot(timestep, signal, 
                      color = 'gray', alpha = 0.5)
    
    line2, = plt.plot(timestep, filtered_signal, 
                      color = 'orange', alpha = 0.5)
    
    # Set axes limits
    plt.axis([0, 0.1, ampl_min, ampl_max])
    
    # Set general title and labels
    plt.title(plot_title)
    plt.xlabel('Seconds')
    plt.ylabel('V')
    
    # Set slider position
    axpos = plt.axes([0.2, 0.1, 0.65, 0.03], 
                     facecolor='lightgoldenrodyellow')
    
    # Put the slider in position and establish limits
    spos = Slider(axpos, 'Scroll (seconds)', 0, len(signal)*0.001-1, 0)
    
    # Nested function for slider update from widgets:
    def update(val):
        pos = spos.val
        # Display 1 sec of the signal (x-axis)
        ax.axis([pos,pos+1,ampl_min,ampl_max])
        fig.canvas.draw_idle()
        
    spos.on_changed(update)
    
    # Legend labels
    ax.legend([line1, line2], [label1, label2])    
    plt.show()
    
    return None