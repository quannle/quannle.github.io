"""
The module for visualizing data in frequency domain
"""

# Rely packages
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from scipy.fft import fftshift

import platform 
if platform.system() == 'Darwin': # Mac OS
    import pywt
    
from pylab import *
import scipy.fftpack
import matplotlib.colors as colors

# Functions
def create_spectrogram(breath_data, title, breath_flag=True):
    """
    Create a spectrogram from collected signal data. For breathing data, 
    frequencies in the range [0, 25] are displayed. For ecg data, frequencies
    in the range [0, 100] are displayed. 

    Inputs: 
    ----------
    breath_data (ls or ndarray): the breath data to create a spectrogram from.
    title (str): the title to be used for the spectrogram

    Optional: 
    breath_flag (bool): True if the input data is breathing data, False if the data is ecg data. 

    Outputs: 
    ----------
    Returns nothing. Instead, plots the generated spectrogram. 
    """
    # Generate the spectrogram
    Pxx, freqs, bins, im = plt.specgram(breath_data, Fs=1000, NFFT=4096, noverlap=2048)

    # leave x range the same, change y (frequency) range to include relevant frequencies only.
    x1,x2,y1,y2 = axis()

    if breath_flag: 
        axis((x1,x2,0,25))
    else: 
        axis((x1,x2,0,100))

    # Set the title of the plot, xlabel and ylabel and display using show() function
    plt.title(title)
    plt.ylabel('Frequency (Hz)')
    plt.xlabel('Time (s)')

    plt.show()


    
def plot_frequency_domain(filtered_signal,
                           sampling_rate=1000.0,
                           start_tick=0,
                           end_tick=-1):
    """
    Plots and returns the signal in 
    frequency domain (Fourier 
    transformed).
    
    Inputs:
    ----------
    filtered_signal (ndarray): the filtered signal
                               (e.g., output of the 
                                breathing_filter 
                                function)
    
    Optional:
    sampling_rate (float): frequency of sampling.
                           The default is 1000 Hz.
    
    start_tick (int): starting time for plots
                      according to comments (
                      output of read_labchart_file)
                      e.g., start_tick = 529349
                      for mouse M21264 is after
                      CNO injection. 
    end_tick (int):   final time for plots.
    The default is [0:-1] plots all datapoints
    to make full Fourier transform.
    
    
    Output:
    -------
    freq_domain (tuple): the frequency axis from 
                         0 to half-sampling rate
                         and the signal amplitudes
    
    """
    
    
    # Fourier transform the entire signal or its part
    # (if start and ticks are different from default)
    ft_signal = scipy.fftpack.fft(filtered_signal[start_tick:end_tick])
    
    # Convert Fourier coefs back to signal amplitude
    n_points = int(len(ft_signal))
    signal_amp = 2*np.abs(ft_signal)/n_points
    
    # Create frequency axis from 0 to 
    # half-sampling rate 
    freq_axis = np.linspace(0, sampling_rate/2, 
                            int(np.floor(n_points/2)+1))
    
    
    # Plot the frequency domain
    plt.figure(figsize=(10,6))
    plt.stem(freq_axis, signal_amp[0:len(freq_axis)], 
             linefmt = 'k-', markerfmt='k-') 
    plt.ylabel('Amplitude')
    plt.xlabel('Frequency')
    plt.title('Frequency domain')
    plt.xlim([0, 30])
    plt.show()
    
    # Return a tuple of frequency domain
    return (freq_axis, signal_amp)



def viz_windows_for_spectrogram(resp_volume,
                                comments,
                                window_sizes,
                                sample_rate=1000.0,
                                save_figures=False):
    
    """
    Note:
    Use with the manually collected mice data.
    
    Plot spectrograms of the same data with
    the determined time windows. The function
    is used for tuning the window for the 
    short-fourier transform for the spectrogram
    (hyperparameter tuning visualization).
    
    Inputs:
    ----------
    resp_volume (ndarray): the respiratory volume 
                           signal (output of the 
                           integrate_for_resp_volume)
                           
    comments (list):       researchers' comments
                           (output of 
                           read_labchart_file)
                           
    window_size (list):    window sizes in sec
                           for short-fourier 
                           transformation
    
    Optional:
    sample_rate (float): frequency of sampling.
                          The default is 1000 Hz.
    
    save_figures (bool): True if opted for saving 
                         figures in .png
    
    
    Output:
    -------
    The function does not have outputs,
    it only plots the spectrograms with
    determined window sizes.
    
    """
    
    # Grid search in spectrogram window sizes:
    for window_size in window_sizes:
        # Number of points in the window
        number_of_points_in_window = int(window_size * sample_rate)
        
        # Obtain short Fourier transforms with the chosen windows parameters:
        frex,time,pwr = signal.spectrogram(resp_volume, sample_rate, 
                                           window=('tukey', number_of_points_in_window), 
                                           nperseg=number_of_points_in_window)
        
        # Plot spectrogram:
        # Increase size of font
        plt.rc('font', size = 16)
        # Put figure size
        plt.figure(figsize=(30,3))
        
        # Create the spectrogram mesh, normalize colorscheme
        plt.pcolormesh(time,frex,pwr, norm = colors.LogNorm(vmin = 1e-9, vmax= 0.7e-5), cmap='cividis')
        
        # Label axes
        plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)') 
        
        # Limit axes based on the filtering (1-30 Hz)
        plt.ylim(0, 30)    
        
        # Title incl. window size
        plt.title('Spectrogram for window size: ' + str(window_size) + ' sec')
        
        # Plot lines when apnea starts:
        for ii in range(0, len(comments)):
            if comments[ii].text == 'apnea starts':
                plt.axvline(x=comments[ii].time, color = 'white',
                            linestyle= '--')
                
        # Show the spectrogram:        
        plt.show()
                
        # Save figures if needed:
        if save_figures:
            fig = plt.gcf()
            plt.show()
            plt.draw()
            fig.savefig('window ' + str(window_size) + \
                        '.png', dpi=500)
            
    return None




def signal_to_spectrogram(resp_volume,
                          comments,
                          window_sizes,
                          sample_rate=1000.0,
                          save_figures=False,
                          plot_exp_times=True,
                          limit_time_axis = True,
                          robo_file=True,
                          mouse_id = '',
                          mouse_group='',
                          ):
    
    """
    Note: use with robotically collected mice data
    or change robo_file to False
    
    Plot spectrograms of the same data with
    the determined time windows. The function
    is used for tuning the window for the 
    short-fourier transform for the spectrogram
    (hyperparameter tuning visualization).
    
    If dealing with manually collected data,
    please specify robo_file = False,
    since manually collected data has
    eupnea manually annotated and 
    do not require eupnea auto-detection
    based on the power spectrum.
    
    Inputs:
    ----------
    resp_volume (ndarray): the respiratory volume 
                           signal (output of the 
                           integrate_for_resp_volume)
                           
    comments (list):       researchers' comments
                           (output of 
                           read_labchart_file)
                           
    window_size (list):    window sizes in sec
                           for short-fourier 
                           transformation
    
    Optional:
    sample_rate (float): frequency of sampling.
                          The default is 1000 Hz.
                          
    plot_exp_times (bool): True if plot experimental
                           times (apnea, challenge,
                           eupnea) as vertical lines.
                          
    robo_file (bool):    manually and robotically
                         collected comments should
                         be treated differently;
                         True: if the file from the
                         new robotically collected set;
                         False: if the file from the 
                         manual dataset.
                         
    limit_time_axis (bool): if True, the time axis
                            starts with 500 sec before
                            the first challenge
    
    save_figures (bool): True if opted for saving 
                         figures in .png
    
    
    Output:
    -------
    The function plots the spectrograms with
    determined window sizes. 
    
    See the outputs in the: 
    demos/signal_to_spectrogram outputs

    
    """
    
    def detect_first_challenge_time(resp_volume, comments, sample_rate, robo_file):
        
        """
        Nested function to extract the first challenge time
        from the experimental data.
        
        """
        
        first_challenge_time = None
        
        if robo_file:
            
            # Recreate timestep 
            timestep = np.arange(0, len(resp_volume)*(1/sample_rate), 1/sample_rate)
            
            # Determine the beginning of the first challenge:
            for ii in range(0, len(comments.values)):
                if 'Starting: On Anoxic' in comments.values[ii]: #challenge starts
                    first_challenge_time = timestep[int(comments.keys()[ii])]
                    break # break when first challenge determined
            
        else: # manually collected data
            for ii in range(0, len(comments)):
                if comments[ii].text == 'apnea starts':
                    first_challenge_time = comments[ii-1].time
                    break
                        
        return first_challenge_time
    
    
    def auto_detect_eupnea(pwr, time, time_apnea, first_challenge_time):
        
        """
        The nested function to auto-detect eupnea
        if it is not annotated (for robotically 
        collected data).
        The function is based on the signal power 
        differences in apnea and normal breathing
        """
        
        # Accurate time window size:
        window_accurate = time[1]-time[0]
        
        # First challenge time to time window
        chal_time_window = int(first_challenge_time/window_accurate)
        
        # Window number when apnea was detected
        n_time_window = int(time_apnea/window_accurate)
        
        # Average power (at 2-8 Hz (frex_ind = 10:40)) 
        # in 100 windows fifty windows before challenge
        #(normal breathing signal power):
        normal_pwr = sum(sum(pwr[10:40, (chal_time_window-150):(chal_time_window-50)])) / 100
        
        # Detect when signal power (2-8 Hz) comes back to normal after apnea:
        # Calculate that signal is of normal breathing power at least in the
        # next 5 windows
        while ( sum(sum(pwr[10:40, n_time_window:(n_time_window+5)])) / 5 ) < normal_pwr:
            n_time_window += 1
            
            # Break if no recovery after apnea (death):
            if n_time_window >= len(time) - 5:
                break
                
        # Convert window number back to second time scale
        time_eupnea = n_time_window * window_accurate
        
        return time_eupnea
    
    

    
    
    def last_apnea_time(comments,
                       timestep):
        """
        The nested function to detect
        last apnea time.
        
        """
        
        last_apnea = timestep[-1]
        
        for ii in range(0, len(comments.values)):
            
            if 'Finished: On Room' in comments.values[ii]: #apnea detected
                last_apnea = timestep[int(comments.keys()[ii])]
                    
        
        return last_apnea 
                        
    
    def plot_experimental_times(resp_volume,
                            comments,
                            pwr, time,
                            sample_rate=1000.0,
                            robo_file = True):
        
        """
        The nested function to plot important 
        experimental times (challenge start, 
        apnea, eupnea recovery) on 
        the spectrograms.    
        """
        
        
        if robo_file:
            
            # Recreate timestep to map timeticks from comments back to sec
            timestep = np.arange(0, len(resp_volume)*(1/sample_rate), 1/sample_rate)
            
            # last apnea time keep in mind
            last_apnea = last_apnea_time(comments, timestep)
            
            first_challenge_time = detect_first_challenge_time(resp_volume, comments, sample_rate, robo_file)
            
            # Extract from comments when apnea is detected (return to room air):
            for ii in range(0, len(comments.values)):
                if 'Finished: On Room' in comments.values[ii]: #apnea detected
                    time_apnea = timestep[int(comments.keys()[ii])];
                    plt.axvline(x=time_apnea, color = 'yellow', linestyle= '--')
                    
                    # Detect eupnea after apnea:
                    if time_apnea < last_apnea:
                        time_eupnea = auto_detect_eupnea(pwr, time, time_apnea, first_challenge_time)
                        plt.axvline(x=time_eupnea, color = 'lightgreen', linestyle= '--')
                
                if 'Starting: On Anoxic' in comments.values[ii]: #challenge starts
                    plt.axvline(x=timestep[int(comments.keys()[ii])], color = 'white', linestyle= '--')
                    
                    # Remember the first challenge time to standartize the beginning
                    if first_challenge_time is None:
                        first_challenge_time = timestep[int(comments.keys()[ii])]
                
        else: # manually collected data
            for ii in range(0, len(comments)):
                if comments[ii].text == 'apnea starts':
                    plt.axvline(x=comments[ii].time, color = 'yellow', linestyle= '--')
                    
                    plt.axvline(x=comments[ii-1].time, color = 'white',
                                linestyle= '--')  # challenge start
                    
                    # Remember the first challenge time to standartize the beginning
                    if first_challenge_time is None:
                        first_challenge_time = comments[ii-1].time
                    
                if comments[ii].text == 'eupnea recovery':
                    plt.axvline(x=comments[ii].time, color = 'lightgreen',
                            linestyle= '--')
                    
        return first_challenge_time
    
    
    
    # Grid search in spectrogram window sizes:
    for window_size in window_sizes:
        # Number of points in the window
        number_of_points_in_window = int(window_size * sample_rate)
        
        # Obtain short Fourier transforms with the chosen windows parameters:
        frex,time,pwr = signal.spectrogram(resp_volume, sample_rate, 
                                           window=('tukey', number_of_points_in_window), 
                                           nperseg=number_of_points_in_window)
        
        # Plot spectrogram:
        # Increase size of font
        plt.rc('font', size = 16)
        # Put figure size
        plt.figure(figsize=(14,3))
        
        # Create the spectrogram mesh, normalize colorscheme
        plt.pcolormesh(time,frex,pwr, norm = colors.LogNorm(vmin = 1e-9, vmax= 0.7e-5), cmap='cividis')
         
        # Label axes
        plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)') 
        
        
        
        # Title incl. window size if several time windows
        if len(window_sizes) > 1:
            plt.title('Spectrogram for window size: ' + str(window_size) + ' sec')
        
        
        # Plot experimental times (apnea / challenge / eupnea) if :
        if plot_exp_times:
            first_challenge_time = plot_experimental_times(resp_volume, comments,pwr, time,
                                                           sample_rate, robo_file)
            
        else:
             first_challenge_time = detect_first_challenge_time(resp_volume, comments, sample_rate, robo_file)
                         
        
        # Limit axes based on the filtering (1-30 Hz)
        plt.ylim(0, 30) 
        plt.xlim(3500, 7000)
        
        # Start time axis 500 sec before the first challenge
        if limit_time_axis:
            plt.gca().set_xlim(left=first_challenge_time - 500)
        
        
        # Save figures for neural network analysis:
        if save_figures:
            # Remove all labels / ticks
            #plt.axis('off') 
            # Save the spectrogram
            plt.savefig(mouse_group + '_' + mouse_id + '.png', dpi=500, bbox_inches='tight', 
                        transparent="True", pad_inches=0)
            print('saved' + mouse_group + '_' + mouse_id)
        
        # Show the spectrogram: 
        plt.title(mouse_group + ': ' + mouse_id)
        plt.show()
                
        
            
        
    