"""
The module for entropy features visualization
"""

# Rely packages
from __future__ import annotations
from typing_extensions import Self
import pandas as pd
import antropy as ant
import random
import numpy as np


# Functions
"""
Class is used to load breathlists and beatlists and perform aggregations on them for windowed entropy calculations.
"""
class EntropyViewer:
    breathlists = None
    beatlists = None
    mids = []
    masked_brl = None
    masked_bl = None

    def __init__(self) -> None:
        pass

    """
    Initializes the bbEntropy class with breathlists and beatlists

    Parameters
    breathlists_path : str
        Path to breathlists csv file
    beatlists_path : str
        Path to beatlists csv file
    """
    def __init__(self, breathlists_path: str, beatlists_path: str):
        random.seed(1000)
        self.load_data(breathlists_path, beatlists_path)


    """
    Loads breathlists and beatlists from the given paths.

    Parameters
    breathlists_path : str
        Path to breathlists csv file
    beatlists_path : str
        Path to beatlists csv file
    """
    def load_data(self, breathlists_path: str, beatlists_path: str):
        try: 
            self.breathlists = pd.read_csv(breathlists_path)
        except: 
            print("error reading in breath list")
        try:
            self.beatlists = pd.read_csv(beatlists_path)
        except:
            print("error reading in beat list")

    """
    Selects breathlist and beatlist for a given list of mice ids

    Parameters
    mids : list[str]
        List of mice ids
    
    Returns
    self : bbEntropy
    """
    def select(self, mids: list[str]) -> Self:
        if self.breathlists is None or self.beatlists is None:
            raise Exception("breathlist or beatlists not loaded")
        self.mids = mids
        self.masked_brl = self.breathlists[self.breathlists["mid"].isin(mids)]
        self.masked_bl = self.beatlists[self.beatlists["mid"].isin(mids)]
        return self

    """
    Sample n mice & corresponding breathlists and beatlists

    Parameters
    n : int
        Number of mice to sample

    Returns
    self : bbEntropy
    """
    def sample(self, n = 5) -> Self:

        if self.breathlists is None or self.beatlists is None:
            raise Exception("breathlist or beatlists not loaded")
        #sample mice ids
        ids = list(self.beatlists["mid"].unique())
        sample = random.sample(ids, n)
        self.masked_bl = self.beatlists[self.beatlists["mid"].isin(sample)]
        self.masked_brl = self.breathlists[self.breathlists["mid"].isin(sample)]
        return self

    """
    Returns masked breathlist dataframe

    Returns
    pd.DataFrame
        Masked breathlist dataframe
    """
    def breaths(self) -> pd.DataFrame:
        return self.masked_brl if self.masked_brl is not None else self.breathlist

    """
    Returns masked beatlist dataframe

    Returns
    pd.DataFrame
        Masked beatlist dataframe
    """
    def beats(self) -> pd.DataFrame:
        return self.masked_bl if self.masked_bl is not None else self.beatlist


    """
    Aggregates beatlist dataframe according to a given time frame in seconds

    Parameters
    keys : list[str]
        List of keys to aggregate by
    freq : str
        Time frame to aggregate by
    burn_in : int
        Number of beats to burn in

    Returns
    pd.DataFrame
        Aggregated beatlist dataframe
    """
    def beat_aggregator(self, keys: list[str], freq = "10s", burn_in = 0) -> pd.DataFrame:
        return self.__aggregator__(self.masked_bl, time_col = "ts", keys = keys, freq = freq, burn_in = burn_in)

    def breath_aggregator(self, keys: list[str], time_col: str, freq = "10s", burn_in = 0) -> pd.DataFrame:
        """
        Aggregates breathlist dataframe according to a given time frame in seconds
        """
        return self.__aggregator__(self.masked_brl, time_col = time_col, keys = keys, freq = freq, burn_in = burn_in)

    """
    Aggregates dataframe into time windows & calculates entropy for each window

    Parameters
    df : pd.DataFrame
        Dataframe to aggregate
    time_col : str
        Column name of time column
    keys : list[str]
        List of keys to aggregate by
    freq : str
        Time frame to aggregate by
    burn_in : int
        Number of beats to burn in

    Returns
    pd.DataFrame
        Aggregated dataframe
    """
    def __aggregator__(self, df: pd.DataFrame, time_col: str, keys: list[str], freq = "10s", burn_in = 0) -> pd.DataFrame:
        burned_dataframe = df.iloc[burn_in: ]

        """
        Calculates approximate entropy as designed in antropy package for a given list of values
        """
        def entropy(x):
            if len(x) < 2:
                return np.NAN
            try:
                entropy_value = ant.app_entropy(np.array(x.values))
                return entropy_value 
            except:
                return np.NAN

        burned_dataframe["time"] = pd.to_timedelta("00:00:" + burned_dataframe[time_col].astype(str))
        agg_funcs = {key: [entropy, len, min, max] for key in keys}
        aggregated_df = burned_dataframe.groupby(pd.Grouper(freq="10s", key = "time")).aggregate(agg_funcs)
        
        return aggregated_df