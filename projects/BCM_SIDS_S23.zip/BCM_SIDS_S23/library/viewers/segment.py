"""
The module for data segmentation
"""

# Rely packages

from __future__ import annotations
from typing_extensions import Self
import pandas as pd
from tqdm import tqdm
import numpy as np
import pickle
import heartpy as hp
import gzip
from collections import defaultdict
import matplotlib.pyplot as plt
import os


# Functions

"""
A class used to select a specific mid, segment, and plot their data
"""

class MidViewer:
    """
    Initializes the MidViewer

    Parameters
    data_dir : str  The directory to load the data from
    """

    def __init__(self, data_dir: str = "./") -> None:
        self.mid = None

        # Check if the data directory exists
        if not os.path.exists(data_dir):
            raise Exception("Data Directory Does Not Exist")

        self.data_dir = data_dir
        self.breaths = pd.DataFrame()

    """
    Selects a specific mid and loads the data
    
    Parameters
    mid : str       The mid to select
    segment : bool  Whether or not to segment the data
        
    Returns
    self : Selector
    """

    def select(self, mid: str, segment: bool = False) -> Self:
        self.mid = mid
        self.__load_data__(mid)
        if segment:
            self.__segment_data__()
        return self

    """
    Wrapper function for the segmentation of the data into breaths

    Parameters
    r : float   The radius of the breaths to segment

    Returns
    self : Selector
    """

    def segment_breaths(self, r: float = 0.3) -> Self:
        if self.mid is None:
            raise Exception("No Mid Selected")
        if self.data is None:
            raise Exception("No Data Loaded")
        self.__segment_breaths__(r)
        return self

    """
    Loads the data for a specific mid

    Parameters
    mid : str   The mid to load the data for
    """

    def __load_data__(self, mid: str) -> None:
        file_path = f"{mid}.pkl.gzip"
        
        # Join the directory and the file paths
        path = os.path.join(self.data_dir, file_path)

        # Check if the data directory contains the mid
        if not os.path.exists(path):
            raise Exception(
                f"Data For {mid} Does Not Exist. Please Download The Data First.")

        print(f"Loading Data For: {mid}")
        with gzip.open(path, "rb") as file:
            self.data = pickle.load(file)
            print(f"Loaded Data For: {mid}")

    """
    Segments the data into phases based on the mode_block
    """

    def __segment_data__(self) -> None:
        print("Segmenting data")
        for i, row in tqdm(self.data.iterrows()):
            keys = defaultdict(lambda: 0)
            block = row["mode_block"]
            if i > 0 and row["mode_block"] != self.data.at[i - 1, "mode_block"]:
                prev_block = self.data.at[i - 1, "mode_block"]
                keys[prev_block] += 1
            self.data.at[i, "phase"] = f"{block}-{keys[block]}"

    """
    Segments the data into breaths

    Parameters
    r : float   The radius of the breaths to segment

    Returns
    self : Selector
    """

    def __segment_breaths__(self, r: float = 0.3) -> None:
        # Create a new dataframe to store the breaths
        breaths = pd.DataFrame()

        # Copy the time and flow data with a low pass filter
        breaths["time"] = self.data["time"]
        filter = hp.filter_signal(
            self.data["FLOW"], cutoff=1, sample_rate=100, filtertype="lowpass")
        breaths["flow"] = filter

        # Find the peaks in the flow data
        peaks = []
        diff = np.diff(filter)
        for i in range(0, len(filter)):
            peaks.append(1 if i + 1 < len(filter)
                         and diff[i] > 0 and diff[i + 1] < 0 else 0)

        # Add the peaks to the breaths dataframe with an additional column for the time of the peak
        peaks = np.array(peaks)
        breaths["peak"] = peaks
        breaths["time_peak"] = peaks * breaths["time"]

        # Get a dense list of the times of the peaks
        peaks = breaths[breaths["peak"] == 1]["time"].values

        print(f"Segmenting Breaths for {self.mid} with r = {r}")
        curPeakI = 0
        for i, row in tqdm(breaths.iterrows()):
            # Necessary calculations for each row
            next_peak = curPeakI + 1 < len(peaks)
            next_breath = i + 1 < len(breaths)
            peak_dist = abs(peaks[curPeakI] - row["time"])
            next_peak_dist = abs(
                peaks[curPeakI + 1] - row["time"]) if next_peak else float("inf")

            # If the current row is a peak, set the time_peak to the time of the peak
            if (peak_dist <= r and peak_dist < next_peak_dist):
                breaths.at[i, "time_peak"] = peaks[curPeakI]
            elif (next_peak and next_breath and  # Ensure that the next peak and breath exist
                  # Ensure that the current row is after the current peak
                  (row["time"] > peaks[curPeakI]) and
                  # Ensure that the next peak is within r of the next breath
                  (peaks[curPeakI + 1] - breaths.at[i + 1, "time"] < r)):
                curPeakI += 1

        # Get the time relative to the peak
        breaths["peak_time"] = breaths["time"] - breaths["time_peak"]

        # Remove the rows that have not been assigned to a cycle
        self.breaths = breaths[breaths["time_peak"] != 0]

    """
    Plots the segmented breaths data for a specific mid

    Parameters
    x : str           The column to plot on the x axis
    y : str           The column to plot on the y axis
    z : str           The column to plot on the z axis
    start : int       The index to start plotting from
    n : int           The number of breaths to plot
    x_label : str     The label for the x axis
    y_label : str     The label for the y axis
    z_label : str     The label for the z axis
    title : str       The title of the plot
    """

    def plot_breaths(self, x: str, y: str, z: str, start: int = 0, n: int = None,
                     x_label: str = None, y_label: str = None, z_label: str = None,
                     title: str = None):
        if self.breaths is None:
            raise Exception("No Breaths Segmented")

        plotter = Plotter(self.breaths)
        plotter.plot(x, y, z, start, n, x_label, y_label, z_label, title)

    def __str__(self):
        return f"Selector for {self.mid}"

    def __repr__(self):
        return self.__str__()


"""
A class used to plot the data in a 3D plot
"""

class Plotter:
    def __init__(self, data) -> None:
        self.data = data

    """
    Plots the data for a specific mid

    Parameters
    x : str          The column to plot on the x axis
    y : str          The column to plot on the y axis
    z : str          The column to plot on the z axis
    start : int      The index to start the plot at
    n : int          The number of data points to plot
    x_label : str    The label for the x axis
    y_label : str    The label for the y axis
    z_label : str    The label for the z axis
    title : str      The title of the plot
    """

    def plot(self, x: str, y: str, z: str, start: int = 0,
             n: int = None, x_label: str = None, y_label: str = None, z_label: str = None,
             title: str = None):
        if self.data is None:
            raise Exception("No Data Loaded")

        # Ensure that the data contains the columns
        if x not in self.data.columns:
            raise Exception(f"{x} is not a valid column")
        if y not in self.data.columns:
            raise Exception(f"{y} is not a valid column")
        if z not in self.data.columns:
            raise Exception(f"{z} is not a valid column")

        # Slice the data
        end = len(self.data) if n is None else start + n
        data = self.data[start:end]

        # Create the figure and axes
        ax = plt.axes(projection="3d")
        x_data = data[x]
        y_data = data[y]
        z_data = data[z]
        ax.plot_trisurf(x_data, y_data, z_data, linewidth=0,
                        antialiased=False, cmap=plt.get_cmap("viridis"))

        ax.set_xlabel(x_label or x)
        ax.set_ylabel(y_label or y)
        ax.set_zlabel(z_label or z)
        ax.set_title(title or f"{x} vs {y} vs {z}")
        plt.show()
