"""
The module for classification of spectrograms
with convolutional neural network

"""

# Rely packages
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.metrics import ConfusionMatrixDisplay
import pickle


# Functions

def prepare_spectrograms_for_model(pickle_filename):
    """
    
    
    Input:
    ----------
    pickle_filename (str): the name of the file 
                           with spectrograms stored
                           as power matrices in tuples
                           with labels ('Control', 
                           'hM3D (Activated)',
                           'hM4D (Suppressed)')
                           
    Outputs:
    ----------
    X_train (np.array): training spectrogram set
    X_val (np.array):   validation (test) 
                        spectrogram set
    y_train (np.array): training labels
    y_val (np.array):   test labels
                           
    """
    
    # To read in spectrograms dataset
    with open(pickle_filename, 'rb') as file:
        data = pickle.load(file)
    
    # Separate labels (y) and spectrograms (X)
    (X, y) = data;
    
    # Convert string labels to number labels
    def labels_str_to_num(y):
        """
        Nested function to convert string labels
        to numeric labels
        
        """
        convertion_dict = {'Control': 0, 'hM3D (Activated)': 1, 'hM4D (Suppressed)': 2}
        
        for ii in range (0, len(y)):
            y[ii] = int(convertion_dict[y[ii]])
            
        return y
    
    y = labels_str_to_num(y)
    
    # Make sure the data are arrays before split:
    X = np.array(X); y = np.array(y)
    
    
    # Split the data in training and validation (test) sets to compare different models
    
    # Stratify the sampling to make sure all classes are represented equally
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, 
                                                  random_state=1000, 
                                                  stratify = y)
    
    return X_train, X_val, y_train, y_val
    
    
    


def spectrograms_2layer_NN(X_train, X_val,
                           y_train, y_val,
                           p, pp, 
                           layer_type, 
                           maxpooling):
    
    '''
    Function to create two-hidden-layers network for
    spectrogram classification
    
   
    Inputs:
    ----------
    X_train (np.array): training spectrogram set
    X_val (np.array):   validation (test) 
                        spectrogram set
    y_train (np.array): training labels
    y_val (np.array):   test labels
    
    p (scalar):         number of neurons 
                        in the 1st hidden layer
                        
    pp (scalar):        number of neurons in the 
                        2nd hidden layer
    layer_type (str):   either 'dense', 
                        or 'convolutional'
    
    maxpooling (True/False): convolutional option 
                              (with maxpooling or not)
    
    Output:
    ----------
    model (keras stacked model): the shallow NN model
    train_acc, val_acc (float): training and validation 
                                classification accuracies
    '''
    
    # Number of classes
    n = len(np.unique(y_train))
    
    # Set up NN
    if layer_type == 'convolutional' and maxpooling == True:
        
        X_train_1 = np.expand_dims(X_train, axis = 3)
        X_val_1 = np.expand_dims(X_val, axis = 3)
            
        model = tf.keras.Sequential(
            [  
                tf.keras.layers.Conv2D(filters = p, kernel_size = (7,7), 
                                       strides = 1, activation = 'relu',
                                       input_shape=(51, 1000, 1), name = 'Conv_1'),
                tf.keras.layers.MaxPooling2D(pool_size=(2, 2), name = 'Pool_1'),
                tf.keras.layers.Conv2D(filters = pp, kernel_size = (7,7), 
                                       strides = 1, activation = 'relu',
                                       input_shape=(51, 1000, 1), name = 'Conv_2'),
                tf.keras.layers.MaxPooling2D(pool_size=(2, 2), name = 'Pool_2'),
                tf.keras.layers.Flatten(),
                tf.keras.layers.Dense(n, activation = 'linear', name = 'output_logits')
            ]
        )
        
        
    elif layer_type == 'convolutional' and maxpooling == False:
        
        X_train_1 = np.expand_dims(X_train, axis = 3)
        X_val_1 = np.expand_dims(X_val, axis = 3)
        
        model = tf.keras.Sequential(
            [  
                tf.keras.layers.Conv2D(filters = p, kernel_size = (7,7), 
                                       strides = 1, activation = 'relu',
                                       input_shape=(51, 1000, 1), name = 'Conv_1'),
                tf.keras.layers.Conv2D(filters = pp, kernel_size = (3,3), 
                                       strides = 1, activation = 'relu',
                                       input_shape=(51, 1000, 1), name = 'Conv_2'),
                tf.keras.layers.Flatten(),
                tf.keras.layers.Dense(n, activation = 'linear', name = 'output_logits')
            ]
        )
    
    else: 
        
        X_train_1 = X_train
        X_val_1 = X_val
        
        model = tf.keras.Sequential(
            [   tf.keras.layers.Flatten(input_shape=(51, 1000), name = 'vectorize'),   
                tf.keras.layers.Dense(p, activation = 'relu', name = 'dense_1'),
                tf.keras.layers.Dense(pp, activation = 'relu', name = 'dense_2'),
                tf.keras.layers.Dense(n, activation = 'linear', name = 'output_logits')
            ]
        )        
        
        
    model._name = layer_type + '_with_' + str(p) + '_and_' + str(pp) + '_neurons'
    # Summarize the model
    model.summary()
    
    # Specify loss and optimization strategy
    model.compile(
        
        # CrossEntropy for more than 2 classes + see expl above
        loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        
        # Optimizer default from the lecture notes
        optimizer=tf.keras.optimizers.Adam(1e-3),
        
        # Classification accuracy
        metrics=['accuracy']
    )
    
    # Train the model
    hist = model.fit(
        X_train_1, y_train,
        epochs=20, #< number of times to apply training data
        verbose = 0  
    )
    
    # Accuracy of the final epoch
    train_acc = hist.history['accuracy'][9]
    print('\nTraining accuracy:', train_acc)
    
    # Validation accuracy
    val_loss, val_acc = model.evaluate(X_val_1,  y_val, verbose = 0) #< turn off for compactness
    print('Validation accuracy:', val_acc, '\n\n')
        
    return model, train_acc, val_acc



def acc_at_different_num_neurons(val_scores):
    '''
    Function to plot val accuracies
    at different numbers of neurons
    in the 1st and 2nd layers    
    
    Input:
    ----------
    val_scores (list): the output from 
                       fashion_2layer_NN()
    '''
    
    # Copy and reshape to matrix
    ar_val_scores = np.array(val_scores);
    ar_val_scores = ar_val_scores.reshape(8, 8)
    
    # Plot heatmap
    fig, ax = plt.subplots(figsize = (6,6))
    im = ax.imshow(ar_val_scores, cmap='viridis') #< scale to see subtle changes
    
    # Label with numbers of neurons to test
    label_ax = ['2', '20', '38', '56', '74', '92', '110', '128'];
    ax.set_xticks(np.arange(len(label_ax)), labels=label_ax)
    ax.set_yticks(np.arange(len(label_ax)), labels=label_ax)
    ax.set_xlabel('#neurons in the 2nd layer', fontsize = 14)
    ax.set_ylabel('#neurons in the 1st layer', fontsize = 14)

    # Plot accuracies (numbers):
    for i in range(len(label_ax)):
        for ii in range(len(label_ax)):
            text = ax.text(ii, i, round(ar_val_scores[i, ii],3),
                       ha="center", va="center", color="r")
    # Title and colorbar
    ax.set_title('Validation accuracy in 2-layer NN', fontsize = 14)
    fig.colorbar(im, fraction=0.046, pad=0.04);
    
    return 




def g_softmax(logits):
    '''
    A helper function to convert logit tensor
    output of NN model into 
    class probabilities
    
    Input:
    ----------
    logits (array): logits values
    
    Output:
    ----------
    probs (array): probabilities
    '''
    logits_exp = np.exp(logits)
    probs = logits_exp/np.sum(logits_exp)
    return(probs)



def pred_to_class(y_pred):
    '''
    Function to convert predicted
    by the model values into
    class predictions (0, 1, 2)
    
    Input:
    ----------
    y_pred (nested list): logits output from 
                          model.predict()
    
    Output:
    ----------
    class_num (scalar): mice group label
                        (0 - Control,
                         1 - Activated,
                         2 - Suppressed)
    
    '''
    y_pred_classes = []
    
    for logit_tensor in y_pred:
        prob = g_softmax(logit_tensor)
        pred_class = np.argmax(prob)
        y_pred_classes.append(pred_class)

    return y_pred_classes



def plot_confusion_matrix(best_model,
                          X_test, y_test):
    
    '''
    Function to plot confusion matrix for
    the chosen model.    
   
    Inputs:
    ----------
    best_model (keras stacked model): the NN model
                                      to plot the confusion
                                      matrix for
    
    X_test (np.array):   test spectrogram set
    y_test (np.array):   test true labels
    
    Output:
    ----------
    The function plots the confusion matrix
    for the chosen model.
    
    '''
    
    # Test the performance of the best model
    _, test_acc = best_model.evaluate(X_test,  y_test);
    
    # Convert model predictions to classes
    y_pred = pred_to_class(best_model.predict(X_test));
    
    print('Test accuracy for shallow NN is ', test_acc)
    print('Confusion matrix for shallow NN:')
    ConfusionMatrixDisplay.from_predictions(y_test, y_pred);
    
    return 