"""
Module to read-in signal data
"""

# Packages 
import platform 
from collections import defaultdict

if platform.system() == 'Windows': 
    import adi
import numpy as np
import pandas as pd

# Functions
def read_labchart_file(filename,
                       channel_id=0,
                       show_comments=True,
                       print_status=True):
    """
    Reads Labchart (.adicht) file structure
    (raw experimental records) and returns
    signal timeseries.
    
    Inputs:
    ----------
    filename (str): the name of the Labchart file    
    
    Optional:
    channel_id (int): the index of channel to read
                      0 - Vent Flow (V)
                      1 - O2 flow (V)
                      2 - CO2 flow (V)
                      3 - chamber temperature (C)
                      4 - electrocardiogram (V)
                      5 - heart rate (BPM)
                      6 - Vent Flow integrated (V)
                      7 - Breathing (Vs-1)
                      The default is 0 channel.
                      
    show_comments (bool): print researchers' comments, 
                          e.g.:
                          Cal = calibration
                          CNO = chemical injection
                          R1 = challenge phase 1
    
    Outputs:
    -------
    signal_data (ndarray): the signal record
    timestep (ndarray): time axis 
    comments (ls): experimental comments
    
    """
    
    # Read the Labchart file
    adi_file = adi.read_file(filename)
    
    # Extract the signal data from the chan of interest
    
    if filename == 'M21267.adicht' or \
       filename == 'M21269.adicht' or \
       filename == 'M20868.adicht':
        
        record_num = 2   # the data are kept in the second record there for some reason
    else:
        record_num = 1;
        
    signal_data = adi_file.channels[channel_id].get_data(record_num)[0:-1]
    
    # Create timestep
    # Extract time tick (seconds):
    time_tick = adi_file.channels[channel_id].dt[0]  
    n_samples =  len(signal_data)
    timestep = np.arange(0, n_samples*time_tick, time_tick)   
    
    # Print channel name:
    if print_status == True:
        print('Inread channel:')
        print(adi_file.channels[channel_id].name)
        # Print channel units:
        print('Inread channel units:')
        print(adi_file.channels[channel_id].units[0])
    
    # Print comments of the records:
    comments = adi_file.records[record_num-1].comments
    if show_comments == 1:
        print(comments)
    
    return signal_data, timestep, comments



def read_flow_from_pickle(filename):
    """
    Reads breathing flow data from 
    a pickle (gzip-compressed) file
    (robotically collected 
    dataset files)
    
    Inputs:
    ----------
    filename (str): the name of the Labchart file    
    
    Outputs:
    -------
    signal_data (ndarray): the signal record
    timestep (ndarray): time axis 
    comments (ls): experimental comments
    
    """
    data = pd.read_pickle(filename, compression='gzip')
    
    timestep = pd.Series.to_numpy(data.time)
    signal_data = pd.Series.to_numpy(data.FLOW)
    # extract non-empty comments
    comments = data.arduino_comments[data.arduino_comments != ''] 
    
    return signal_data, timestep, comments


def get_mode_blocks(df, verbose=0):
	"""
	We assume the dataframe has an appropriate mode_block column. 
	Creates a dictionary that maps modes to [start_idx, end_idx]
	arrays. 
	
	Inputs:
	----------
	df (pandas dataframe): The data frame (read from a .pkl file)
	verbose (integer): level of verobsity to use for printing

	Outputs: 
	----------
	modes (dict): mapping of modes (str) to a list of length 2. 
				  The first list elem is the start idx, and the second is the end 
				  idx (inclusive)
	"""
	modes = defaultdict(list)
	current_mode = ""
	if verbose:
		print("Getting modes")

	# Iterate to find mode index blocks
	for i, mode in enumerate(df.mode_block):
		if mode != current_mode:
			# Add an ending index to the prev mode block if one exists
			if current_mode != "":
				modes[current_mode].append(i-1)
			
			# Start the new mode block and record its beginning index
			modes[mode].append(i)
			current_mode = mode

			if verbose: 
				print(f"index {i}, {mode}")

	return modes

def extract_challenge_phase_cycles(data, verbose=0): 
    """
	Given the raw data, find the timestamps that 
    mark the start times of each challenge phase cycle. 
    
    The first challenge phase cycle is defined as the first milisecond
    of anoxic gas exposure up to but not including the first
    milisecond of room air exposure. 

    All subsequent cycles are defined as the first milisecond of 
    room air exposure up to but not including the first milisecond of 
    room air exposure from the next phase (if it exists). This is to handle 
    the case of the final cycle, where the mouse expires and no more meaningful data
    even though room air gas starts. 
	
	Inputs:
	----------
	data (pandas dataframe): The data frame (read from a .pkl file)
	verbose (integer): level of verobsity to use for printing

	Outputs: 
	----------
	cycles (list): a list of 2 element lists. Each inner list represents the 
                              inclusive indices of a challenge phase cycle using the format 
                              [start_idx, end_idx].
	"""
    cycles = [] 

    # These strings are the comments used to mark the starts and ends of challenge cycles. 
    anoxic_gas_str = 'Starting: On Anoxic Air,Prefill for 10s,Ongoing: On Position 3, Prefilled for 10s'
    room_air_str = 'Finished: On Room Air'
    cycle_start_idx = -1
    
    # Iterate over the comments to extract cycles
    for i, comment in enumerate(data.arduino_comments): 
        if comment == anoxic_gas_str: 
            # This is the first cycle, so the start of anoxic gas counts as the start index
            if cycle_start_idx == -1: 
                cycle_start_idx = i
        # The start of room air marks the end of an old cycle and the beginning of a new cycle
        elif comment == room_air_str: 
            cycles.append([cycle_start_idx, i - 1])
            cycle_start_idx = i
    
    return cycles






	

    

