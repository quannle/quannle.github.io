"""
The module for denoising ECG data
"""
# Packages:
import pandas as pd
import numpy as np
from scipy import signal

# Functions:
def ecg_bt_denoise(ecg_data, low_cut = 0.1, high_cut = 150):
    '''
    This function denoises the original ecg signal by applying the butterworth 
    bandpass filter.

    
    Parameters
    ----------
    ecg_data : List
        The original ecg signal data.
    low_cut : Int
        Low cut frequency for ecg signal.
    high_cut : Int
        High cut frequency for ecg signal.

    Returns
    -------
    ecg_filtered_data : List
        The denoised ecg signal data.

    '''
    
    # Set up butterworth filter parameters
    fs = 1000
    nyq = 0.5 * fs
    low = low_cut / nyq
    high = high_cut / nyq
    b, a = signal.butter(2, [low, high], btype='band')
    
    # Apply butterworth filter to ecg signal
    ecg_filtered_data = signal.filtfilt(b, a, ecg_data)
    
    return ecg_filtered_data
    
    
def breath_bt_denoise(breath_data, low_cut = 1, high_cut = 60):
    '''
    This function denoises the original breath volmue signal by applying the 
    butterworth bandpass filter.

    Parameters
    ----------
    breath_data : List
        The original breath volmue signal data.
    low_cut : Int
        Low cut frequency for breath volmue signal.
    high_cut : Int
        High cut frequency for breath volmue signal.

    Returns
    -------
    breath_filtered_data : List
        The denoised breath volmue signal data.

    '''
    # Set up butterworth filter parameters
    fs = 1000
    nyq = 0.5 * fs
    low = low_cut / nyq
    high = high_cut / nyq
    b, a = signal.butter(2, [low, high], btype='band')
    
    # Apply butterworth filter to breath signal
    breath_filtered_data = signal.filtfilt(b, a, breath_data)
    
    return breath_filtered_data
