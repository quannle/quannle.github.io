"""
The module for denoising respiratory flow chart and 
integrating for respiratory volume
"""

# Rely packages
from scipy import signal
import scipy.integrate as integrate

# Functions:
def breathing_filter(signal_data,
                     sample_Hz=1000.0,
                     high_pass=1,
                     high_pass_order=2,
                     low_pass=30,
                     low_pass_order=10,
                     ):
    
    """
    Applies a highpass and lowpass filter to data rray, useful 
    for reducing artifacts from electrical noise or bias flow 
    pump vibrations. It is intended for use on a plethysmography or 
    pneumotacography 'flow' signal.
    Modified from Lusk et al., 2023 (bioRxiv).
    
    Inputs:
    ----------
    signal_data (ls, ndarray, or dataframe): signal to be filtered.
                                             If dataframe: select 
                                             the right column.
    
    Optional:
    sample_Hz (float): sampling rate. The default is 1000,
    high_pass (float): frequency cutoff (Hz) for the highpass filter. 
                       The default is 1.0.
    high_pass_order (int): order value for the high pass filter. 
                       The default is 2.
    low_pass (float): frequency cutoff (Hz) for the low_pass filter. 
                       The default is 30.
    low_pass_order (int): order value for the low pass filter. 
                       The default is 10.
     
    Outputs:
    -------
    lpf_hpf_signal (ls, or ndarray): filtered signal data
    
    
    Usage example (respiratory flow data):
    -------
    signal_data = read_labchart_file('M21264.adicht')
    filtered_signal = breathing_filter(signal_data)
    
    """
    
    # High-pass filter design
    hpf_b, hpf_a = signal.butter(
        high_pass_order, high_pass/(sample_Hz/2), 'high')
    
    # Apply high-pass filter 
    hpf_signal = signal.filtfilt(hpf_b, hpf_a, signal_data)

    # Low-pass filter design
    lpf_b, lpf_a = signal.bessel(low_pass_order, low_pass/(sample_Hz/2), 'low')
    
    #Apply low-pass filter
    filtered_signal = signal.filtfilt(lpf_b, lpf_a, hpf_signal)
    
    #print('The signal is filtered')

    return filtered_signal  



def integrate_for_resp_volume(filtered_signal, 
                              timestep):
    """
    Integrate respiratory flow rate
    for respiratory volume (a more 
    biologically relevant measurement).
    
    Inputs:
    ----------
    filtered_signal (ndarray): the filtered signal
                               (e.g., output of the 
                                breathing_filter 
                                function)
    timestep (ndarray):        time points
    
    Output:
    -------
    resp_volume (ndarray):     breathing volume 
                               signal
    
    """
    # Cummulatively integrate resp flow:
    resp_volume = integrate.cumtrapz(filtered_signal, 
                                     timestep, 
                                     dx = 0.001)
    
    return resp_volume