"""
The module for frequency domain feature engineering
"""


# Rely packages
import numpy as np
import pandas as pd
from scipy import signal
from scipy.stats import skew, mstats
from scipy.fft import *
from pywt import wavedec


# Functions
def extract_wavelet_transform_features(data, wavelet='sym4', breath_flag=True): 
    """
    Given a segment of signal data, apply the discrete wavelet 
    decomposition and extract frequency domain features. 

    Since the sampling frequency is 1kHz, by the Nyquist theorem, 
    the highest frequency signal is half the sampling rate, or 500kHz. 
    The range of ~0-20Hz is of interest for breathing data, so we will apply 4 levels of 
    decomposition (giving a range of 0-500/16, or 0-31.25Hz). 
    
    The following features will be extracted after the decomposition: 
        Average Power
        Mean Absolute Value
        Variance
        Mean
        Skewness
        Standard Deviation
        Range
        Max

        Entropy
    
    Inputs: 
    ----------
    data (ls or ndarray): a signal comprised of float values. For best
                          performance, this should be a denoised signal. 
    
    Optional 

    wavelet (str): the type of wavelet to use. By default, sym4 (symlet 4) is used.
    breath_flag (bool): flag indicating whether or not the input is breathing data. 
                        If the flag is False, one less decomposition is performed 
                        to give a range of 0-62.5Hz (for ECG data). 
    
    Outputs: 
    ----------
    features (dict[str]->float): a dictionary of features mapping feature string 
                                 names to their associated mathematical values
    """
    features = {}

    # 4 levels of decompositions yields 0-31.25Hz, 0-62.5 for 3 levels. 
    level = 4 if breath_flag else 3

    # Compute the DWT with specified number of levels and extract approximations
    coeffs = wavedec(data, wavelet, level=level)
    cA = np.array(coeffs[0])

    # Compute Average Power 
    features['wavelet_avg_power'] = np.sum(np.abs(cA) ** 2) / len(cA)

    # Compute Mean Absolute Value 
    features['wavelet_mean_abs_val'] = np.sum(np.abs(cA)) / len(cA)

    # Compute variance 
    features['wavelet_variance'] = np.var(cA)

    # Compute mean
    features['wavelet_mean'] = np.mean(cA)

    # Compute Skewness
    features['wavelet_skew'] = skew(cA)

    # Compute Standard Deviation
    features['wavelet_std'] = np.std(cA)

    # Compute Range
    features['wavelet_range'] = max(cA) - min(cA)

    # Compute Max
    features['wavelet_max'] = max(cA)

    # Compute Shannon Entropy with shifted values to avoid log(0)
    shifted = cA + np.abs(np.min(cA)) + 1
    cA_norm = shifted / np.sum(shifted)
    entropy = -np.sum(cA_norm * np.log2(cA_norm))
    features['wavelet_entropy'] = entropy

    return features

    
def extract_fft_features(data, fs=1000, NFFT=4096, noverlap=2048): 
    """
    Extracts features from the Fast Fourier Transform (and power spectral density computed using 
    Welch's method). 

    Inputs: 
    ----------
    data (ls or ndarray): a signal comprised of float values. For best
                          performance, this should be a denoised signal. 
    
    Optional 

    fs (int): The sampling frequency of the input signal
    NFFT (int): Length of the FFT used, if a zero padded FFT is desired. Defaults to 4096.
    noverlap (int): Number of points to overlap between segments. Defaults to 2048.

    Outputs:
    ----------
    features (dict[str]->float): a dictionary of features mapping feature string 
                                 names to their associated values.
    """
    features = {}

    # Compute the PSD
    f, Pxx_den = signal.welch(data, fs, nperseg=NFFT, noverlap=noverlap)

    # Compute Average Power
    features['psd_average_power'] = np.mean(Pxx_den)
    
    # Compute Median Frequency (freq where half the power is below and half the power is above)
    cumsum = np.cumsum(Pxx_den)
    features['psd_med_freq'] = f[np.where(cumsum>np.max(cumsum)/2)[0][0]]  
    
    # Compute Peak Frequency (frequency where the PSD takes on the highest value)
    features['psd_peak_freq'] = f[np.argmax(Pxx_den)]

    # Compute Total Power (the integral of the PSD across all frequencies.)
    features['psd_total_power'] = sum(Pxx_den)

    # Compute Spectral Entropy
    Pxx_norm = Pxx_den / np.sum(Pxx_den)
    spectral_entropy = -np.sum(Pxx_norm * np.log2(Pxx_norm))
    features['spectral_entropy'] = spectral_entropy

    # Compute Spectral Flatness (ratio of the geometric mean of a spectrum to its arithmetic mean.)
    # This is also known as the Wiener entropy. 
    features['spectral_flatness'] = mstats.gmean(Pxx_den) / np.mean(Pxx_den)

    # Compute Spectral Centroid (the "center of gravity" of the PSD)
    spectral_centroid = np.sum(f * Pxx_den) / np.sum(Pxx_den)
    features['spectral_centroid'] = spectral_centroid

    # Compute Spectral Variance (how spread out the energy in the PSD is around the central frequency)
    spectral_variance = np.sum((f - spectral_centroid) ** 2 * Pxx_den) / np.sum(Pxx_den)
    features['spectral_variance'] = spectral_variance

    # Compute Spectral Skewness (the asymmetry of a PSD estimate around its spectral centroid)
    spectral_skewness = np.sum((f - spectral_centroid) ** 3 * Pxx_den) / (np.sum(Pxx_den) * spectral_variance ** (3/2))
    features['spectral_skewness'] = spectral_skewness

    # Compute Spectral Kurtosis (captures whether the energy in the PSD is concentrated in 
    # a narrow peak or is more spread out. A positive spectral kurtosis indicates that 
    # the energy is concentrated in a narrow peak, whereas a negative spectral kurtosis 
    # indicates that the energy is more spread out. A zero spectral kurtosis indicates that the 
    # energy is evenly distributed.)
    spectral_kurtosis = np.sum((f - spectral_centroid) ** 4 * Pxx_den) / (np.sum(Pxx_den) * spectral_variance ** 2) - 3
    features['spectral_kurtosis'] = spectral_kurtosis

    return features

def extract_all_features(data, fs=1000, NFFT=4096, noverlap=2048, wavelet='sym4', breath_flag=True): 
    """
    Extracts all features from the input data. 
    
    Inputs: 
    ----------
    data (ls or ndarray): a signal comprised of float values. For best
                          performance, this should be a denoised signal. 
    
    Optional 

    fs (int): The sampling frequency of the input signal
    NFFT (int): Length of the FFT used, if a zero padded FFT is desired. Defaults to 4096.
    noverlap (int): Number of points to overlap between segments. Defaults to 2048.
    wavelet (str): the type of wavelet to use. By default, sym4 (symlet 4) is used.
    breath_flag (bool): flag indicating whether or not the input is breathing data. 
                        If the flag is False, one less decomposition is performed 
                        to give a range of 0-62.5Hz (for ECG data). 
    
    Outputs: 
    ----------
    features (dict[str]->float): a dictionary of features mapping feature string 
                                 names to their associated values.
    """
    features = {}

    # Extract features from the DWT
    features.update(extract_wavelet_transform_features(data, wavelet=wavelet, breath_flag=breath_flag))

    # Extract features from the FFT
    features.update(extract_fft_features(data, fs=fs, NFFT=NFFT, noverlap=noverlap))

    return features
