"""
The module for entropy features engineering
"""


# Rely packages


# Functions