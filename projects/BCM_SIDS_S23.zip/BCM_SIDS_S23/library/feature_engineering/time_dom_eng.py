"""
The module for time domain feature engineering
"""


# Rely packages
import pandas as pd
import numpy as np


# Functions
def extract_breath_features(breathlist, start_time: float, end_time: float, midpoint: float): 
    """
    Given a mouse's breathlist file, and the start and end times 
    for each trial, extract features based on every column containing
    data about the mouse's breaths. 
    
    The following features will be extracted for each relevant column: 
        Mean
        Median
        Variance
        Standard Deviation
        Range
        Max
        Skewness
        Kurtosis

    
    Inputs: 
    ----------
    breathlist (pd df): a data frame where each row is a breath, and each column
                        contains biological measurments about the breaths. 
                        This can be obtained by using pd.read_csv on the 
                        .csv breathlist file.

    start_time (float): the starting time (to the nearest ms) of the observation. 

    end_time (float): the ending time (to the nearest ms) of the observation. 
    
    midpoint (float): the timestamp where the observation switches from regular
                      room air gas to anoxic gas. 
    
    Outputs: 
    ----------
    features: a dictionary where the keys are the string identifiers of the extracted
              features and the values are the numerical values derived from the breaths. 
              2 sets of features are computed (1 for each gas type), and the keys are 
              formatted in the style "(gas type)_(column name)_(statistic)"

              For example, one key may be anoxic_Peak_Inspiratory_Flow_mean
    """
    # For this computation, define "included breaths" as breaths that begin after start_time 
    # and do not begin after end_time
    start_idx, mid_idx, end_idx = None, None, None

    # Find the indices of the breaths for each gas type
    for idx, row in breathlist.iterrows():
        inspiration_timestamp = row['Timestamp_Inspiration']
        # Check the inspiration timestamp isn't missing
        if np.isnan(inspiration_timestamp):
            continue 
        # If the inspiration time is after the end time, don't count these breaths. 
        elif inspiration_timestamp > end_time: 
            break 

        # Update the start, mid, and end indices. 
        if start_idx != None and inspiration_timestamp >= start_time: 
            start_idx = idx
        
        if mid_idx != None and inspiration_timestamp >= midpoint: 
            mid_idx = idx

        end_idx = idx
    
    # Subset dfs to include relevant breaths
    normal_breaths = breathlist[start_idx:mid_idx]
    anoxic_breaths = breathlist[mid_idx: end_idx]

    normal_gas_features = compute_statistics('normal_gas', normal_breaths)
    anoxic_gas_features = compute_statistics('anoxic_gas', anoxic_breaths)

    # Return the union of the 2 feature sets
    return normal_gas_features | anoxic_gas_features 

def compute_statistics(gas, breaths, exclude = []):
    """
    Helper function that computes statistics given a curated list of breaths.

    Inputs: 
    ----------
    gas (str): 'anoxic' or 'normal', a prefix used for labeling feature names. 
    breaths (pd df): a list of breaths to compute statistics over. 

    Outputs: 
    ----------
    features (dict): mapping of feature names to the computed value for that feature over all breaths. 
                        By default, missing values are ignored. 
    """
    # Set of features to exclude when computing statistics. 
    exclude_set = set(["Timestamp_Inspiration", "Timestamp_Expiration", "ts_end", "Breath Number", "il_exhale", 
                      "il_end", "Chamber_Temp_uncalibrated", "Chamber_Temperature", "Body_Temperature_Linear", 
                      "RUID", "Line", "Genotype", "Trial", "group", "treatment", "age", "sex", "rotometer_standard_curve_readings", 
                      "rotometer_standard_curve_flowrates", "chamber_temperature_units", "chamber_temperature_narrow_fix", 
                      "chamber_temp_cutoffs", "maxTV", "maxVEVO2", "Aggregate_Output", "Pneumo_Mode", "PM_trim_for_hypervent_phase", 
                      "PM_condition_to_use_for_baseline", "Version", "Weight", "MAN_IND_INCLUDE", "gas_minimum_TI", "Irreg_Score_Body_Temperature_Linear",
                      "Irreg_Score_Chamber_Temp_uncalibrated"])
    
    # Add any additional features to exclude
    exclude_set = exclude_set | set(exclude)

    features = {}

    # For each column, compute desired statistics. Note that each function ignores na vals by default. 
    for column in breaths.copy(): 
        # Exclude unwanted columns
        if column in exclude_set or breaths[column].dtype == 'object': 
            continue 

        # Exclude columns with at least 50% of values missing
        if breaths[column].isnull().sum() >= len(breaths) / 2: 
            continue 
        
        # If something is already a statistic (i.e. all values are the same in a column), add it directly
        # to the feature dictionary. The gas type is checked so these features are added only once. 
        if (len(np.unique(breaths[column])) == 1 or breaths[column].var() == 0) and gas == 'normal_gas':
            features[column] = breaths[column][0]
            continue
        elif (len(np.unique(breaths[column])) == 1 or breaths[column].var() == 0) and gas == 'anoxic_gas':
            continue
        
        feature_prefix = gas + '_' + column + '_'

        # Skip any columns that don't contain numerical data
        if not np.issubdtype(breaths[column].dtype, np.number):
            continue

        # Ensure the slice is not empty
        if len(breaths[column]) == 0:
            continue

        # Mean 
        features[feature_prefix + 'mean'] = breaths[column].mean()
        
        # Median 
        features[feature_prefix + 'median'] = breaths[column].median()

        # Variance 
        features[feature_prefix + 'variance'] = breaths[column].var()

        # Standard Deviation
        features[feature_prefix + 'std'] = breaths[column].std()

        # Range
        features[feature_prefix + 'range'] = breaths[column].max() - breaths[column].min()

        # Max
        features[feature_prefix + 'max'] = breaths[column].max()

        # Skewness
        features[feature_prefix + 'skew'] = breaths[column].skew()

        # Kurtosis
        features[feature_prefix + 'kurtosis'] = breaths[column].kurtosis()

    return features








    
    
