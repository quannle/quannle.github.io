from library import read_data
from library.feature_engineering import freq_dom_eng
from library.denoise import breath
import pandas as pd
import os
import argparse

# Parse args
parser = argparse.ArgumentParser(description='Extract frequency domain features from a raw data file')
required = parser.add_argument_group('required arguments')
required.add_argument('--data_dir', type=str, help='path to pkl file', required=True)
required.add_argument('--meta_dir', type=str, help='path to metadata file', required=True)
required.add_argument('--ecg_dir', type=str, help='path to ECG file', required=True)
required.add_argument('--mouse_id', type=str, help='ID of mouse referenced in data file', required=True)
args = parser.parse_args()

# Set path vals and mouse id
data_path = args.data_dir
meta_path = args.meta_dir
ecg_path = args.ecg_dir
mouse_id = args.mouse_id

# Read data
df = pd.read_pickle(data_path)
ecg = pd.read_csv(ecg_path)
meta_df = pd.read_csv(meta_path)

# Get cycle index
ind = read_data.extract_challenge_phase_cycles(df)

# Extract features
wav_features = pd.DataFrame()
fft_features = pd.DataFrame()
RR_features = []

for index in ind:
    wav_features = wav_features.append(
        freq_dom_eng.extract_wavelet_transform_features(breath.breathing_filter(df.FLOW[index[0]:index[1]])), 
        ignore_index = True)

    fft_features = fft_features.append(
        freq_dom_eng.extract_fft_features(breath.breathing_filter(df.FLOW[index[0]:index[1]])),
        ignore_index = True)
    
    ecg_seg = ecg[(ecg.ts>=(index[0]/1000))&(ecg.ts<=(index[1]/1000))]
    RR_features.append( ecg_seg['RR'].sum() / len(ecg_seg) )
    
features = pd.concat([wav_features, fft_features], axis=1)
features['RR'] = RR_features
features['start_index'] = [a[0] for a in ind]
features['end_index'] = [a[1] for a in ind]
features['Mouse ID'] = mouse_id 
features['Genotype'] = meta_df[meta_df['RUID']==mouse_id].Genotype.tolist()[0]
features['Weight'] = meta_df[meta_df['RUID']==mouse_id].Weight.tolist()[0]

# Output to cvs
outpath = './results'
os.mkdir(outpath)  
features.to_csv(outpath + '/' + mouse_id + '_features.csv', index=False)

