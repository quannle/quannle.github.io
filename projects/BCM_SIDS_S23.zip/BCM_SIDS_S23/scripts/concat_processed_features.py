"""
CLI script that takes in a directory of processed features that are CSV files
and concatenates them into a single CSV file.
"""

import os
import sys
import argparse
import pandas as pd
from tqdm import tqdm

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data_dir", type=str, help="Directory of processed features")
    parser.add_argument("output", type=str, help="Output file")
    args = parser.parse_args()

    # Get all the files in the data directory
    files = [f for f in os.listdir(args.data_dir) if f.endswith(".csv")]

    # Array of dataframes
    dfs = []

    # Iterate over the rest of the files and append them to the dataframe
    with tqdm(total=len(files)) as pbar:
        for f in files:
            dfs.append(pd.read_csv(f"{args.data_dir}/{f}"))

            # Set the description to the current file
            pbar.set_description(f)
            pbar.update(1)

    # Concatenate the dataframes
    df = pd.concat(dfs)

    # Write the dataframe to a CSV file
    df.to_csv(args.output, index=False)

if __name__ == "__main__":
    main()