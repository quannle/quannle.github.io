import pandas as pd
import os
import sys

# The first argument is the directory of the processed lists
# The second argument is the output file

if len(sys.argv) != 5:
    print("Usage: python scripts/create_large_dataset.py <data_dir> <list_dir> <robo_rig_file> <output>")
    sys.exit(1)

# Parse the args
data_dir = sys.argv[1]
list_dir = sys.argv[2]
output = sys.argv[3]
roborig = sys.argv[4]

# Get all of the csv files
files = [f for f in os.listdir(f"./{data_dir}/{list_dir}") if f.endswith(".csv")]

breaths = [f for f in files if "breath" in f]
breaths = [pd.read_csv(f"./{data_dir}/{list_dir}/{f}") for f in breaths]

beats = [f for f in files if "beat" in f]
beats = [pd.read_csv(f"./{data_dir}/{list_dir}/{f}") for f in beats]

# Concatenate the dataframes
breaths = pd.concat(breaths)
beats = pd.concat(beats)

# Fix the mid column by removing the _breath or _beat
breaths["mid"] = breaths["mid"].astype(str).apply(lambda x: x.split("_")[0])
beats["mid"] = beats["mid"].astype(str).apply(lambda x: x.split("_")[0])

# Merge the breaths and beats
lists = breaths.merge(beats, on=["mid", "sub_mode_block_id"])

# Fix the sub_mode_block_id column by removing the sub_mode_ prefix
lists["sub_mode_block_id"] = lists["sub_mode_block_id"].astype(str).apply(lambda x: x.split("-")[-1].lower()) 

# Read in the concatenated data
robo = pd.read_csv(f"./{data_dir}/{roborig}")

# Sort by mid and start_mode_block_start
robo = robo.sort_values(["mid", "sub_mode_block_start"])

# Iterate over the rows and for each sub_mode_block_id, give it a unique id which resets per mid
for i, row in robo.iterrows():
    if i == 0:
        robo.loc[i, "sub_mode_block_id"] = 0
        continue

    if robo.loc[i, "mid"] == robo.loc[i - 1, "mid"]:
        robo.loc[i, "sub_mode_block_id"] = robo.loc[i - 1, "sub_mode_block_id"] + 1
    else:
        robo.loc[i, "sub_mode_block_id"] = 0


# Merge the lists and robo
all = pd.merge(lists, robo, on=["mid", "sub_mode_block_id"],  how="inner")

# Write to csv
all.to_csv(f"./{data_dir}/{output}", index=False)
