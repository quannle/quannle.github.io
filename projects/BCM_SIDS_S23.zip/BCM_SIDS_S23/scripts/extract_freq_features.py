import os
import sys
import pandas as pd
from tqdm import tqdm
from boxsdk import Client

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from library.feature_engineering.freq_dom_eng import extract_all_features
from library.data.BCMDataLoader import BCMDataLoader

data_dir = "data"

loader = BCMDataLoader(data_dir=data_dir, verbose=True)

for mid in (p := tqdm(loader)):
    # If the file already exists, skip it
    if os.path.exists(f"./{data_dir}/processed/{mid}.csv"):
        continue

    try:
        p.set_description(f"Processing {mid}")
        
        # Load the data
        data = loader.get(mid)

        # Delete the file after it is iterated over
        if os.path.exists(f"{data_dir}/{mid}.pkl"):
            os.remove(f"{data_dir}/{mid}.pkl")

        # Delete the metadata file if it exists
        if os.path.exists(f"{data_dir}/{mid}_metadata.pkl"):
            os.remove(f"{data_dir}/{mid}_metadata.pkl")

        if data is None:
            continue

        # Get disk usage
        usage = sys.getsizeof(data)
        p.set_postfix({"usage": f"{usage / 1024 / 1024:.2f}mb"})

        data = data[data["sub_mode_block_id"].notnull()]
        data = data[["genotype", "FLOW", "ECG", "sub_mode_block_id", "sub_mode_block_start", "sub_mode_block_end", "observation_id", "observation_start", "observation_end"]]


        # Group by sub_mode_block_id and extract the features for each block
        features = data.groupby("sub_mode_block_id").agg({
            "FLOW": lambda x: extract_all_features(x.values, breath_flag=True),
            "ECG": lambda x: extract_all_features(x.values, breath_flag=False),
            "genotype": lambda x: x.values[0],
            "sub_mode_block_start": lambda x: x.values[0],
            "sub_mode_block_end": lambda x: x.values[0],
            "observation_id": lambda x: x.values[0],
            "observation_start": lambda x: x.values[0],
            "observation_end": lambda x: x.values[0],
        })

        # Take the dicts in the FLOW and ECG columns and make them columns prefexed with FLOW_ and ECG_
        flow_features = features["FLOW"].apply(pd.Series).add_prefix("FLOW_")
        ecg_features = features["ECG"].apply(pd.Series).add_prefix("ECG_")

        features = pd.concat([
            features.drop(columns=["FLOW", "ECG"]),
            flow_features,
            ecg_features
        ], axis=1)

        # Sort by sub_mode_block_start
        features = features.sort_values("sub_mode_block_start")

        # Add mid as first column
        features.insert(0, "mid", mid)

        features.to_csv(f"./data/processed/{mid}.csv", index=False)
    except Exception as e:
        print(f"Error processing {mid}: {e}")

        # Refresh the oauth token
        p.set_description(f"Refreshing OAuth token")
        loader.refresh_oauth()