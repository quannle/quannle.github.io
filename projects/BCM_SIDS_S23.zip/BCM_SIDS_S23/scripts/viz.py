from library import read_data
from library.feature_engineering import freq_dom_eng
from library.denoise import breath
import pandas as pd
import os
import argparse
import matplotlib.pyplot as plt

df = pd.read_pickle('/Users/danielliang/Downloads/R1568_12-1-22.pkl')
ind = read_data.extract_challenge_phase_cycles(df)

first_challenge = ind[0]
last_challenge = ind[-1]

print(first_challenge, last_challenge)

first_cycle_signal = breath.breathing_filter(df.FLOW[first_challenge[0]:first_challenge[1]])
last_cycle_signal = breath.breathing_filter(df.FLOW[last_challenge[0]:last_challenge[1]])


# Plot first cycle psd
plt.psd(first_cycle_signal, Fs=1000, NFFT=2048, noverlap=1024)
plt.show()

# Plot second cycle psd
plt.psd(last_cycle_signal, Fs=1000, NFFT=2048, noverlap=1024)
plt.show()


