import argparse
import pandas as pd
import os
from tqdm import tqdm
import random

# Run this script to concatenate all breathlists and beatlists into one file
# you can run this script with the following command example:
# python concat.py --data_dir ./breathlist_beatlist/ --output_dir ./output/ --k 50

# Argument parser
parser = argparse.ArgumentParser(description='Concatenate breathlists and beatlists into one file')
parser.add_argument('--data_dir', type=str, help='path to breathlists and beatlists directory')
parser.add_argument('--output_dir', type=str, help='path to output directory')
parser.add_argument('--k', type=int, help='number of mice IDs to sample')
args = parser.parse_args()


# WARNING: This script will take a long time to run
# Change to your directory for all downloaded breathlists beatlists files
# You should have approximately 992 files in this directory
data_dir = "./breathlist_beatlist/" if args.data_dir is None else args.data_dir
output_dir = "./output/" if args.output_dir is None else args.output_dir
k = 50 if args.k is None else args.k


# Make the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.mkdir(output_dir)

# Ensure the data directory exists and has over 500 files
if not os.path.exists(data_dir):
    raise Exception("Data directory does not exist")
files = os.listdir(data_dir)
if len(files) < 500:
    raise Exception("Data directory does not have enough files")

dataframes = []
beatlists = []
breathlists = []

# Iterate through all files in data_dir and concatenate them into one dataframe array either the
# beatlist or breathlist array
for file in tqdm(files):
    mid = file.split("_")[0]
    oneDF = pd.read_csv(os.path.join(data_dir, file))
    oneDF["mid"] = mid
    if "beat" in file:
        beatlists.append(oneDF)
    if "breath" in file:
        breathlists.append(oneDF)

# Concatenate all beatlists and breathlists into one dataframe
allBeatLists = pd.concat(beatlists)
print("Done concatenating", allBeatLists.shape)
allBreathLists = pd.concat(breathlists)
print("Done concatenating", allBreathLists.shape)
allBeatLists.to_csv("RobotRigAllMiceHeartbeat.csv", index = False)
print("Done writing beat lists to file")
allBreathLists.to_csv("RobotRigAllMiceBreaths.csv", index = False)
print("Done writing breath lists to file")

def getDfSample(df, k=5):
    """
    Sample k mice IDs & cocatenate their corresponding breathlists & beatlists into a dataframe.

    Parameters: 
        df: either large breathlist or large beatlist
        k: number of mice IDs to sample
    """
    ids = list(df["mid"].unique())
    sample = random.sample(ids, k)
    sampledf = df[df["mid"].isin(sample)]
    print("Sampled DF of shape {df.shape} with k = {k} and returned DF with shape {sampledf.shape}")
    return sampledf

# Generate a breathlist & beatlist with k mice IDs and write them to file
sampledBeats = getDfSample(allBeatLists, k)
sampledBeats.to_csv(os.path.join(output_dir, f"beats-k-{k}.csv"), index = False)
sampledBreaths = getDfSample(allBreathLists, k)
sampledBreaths.to_csv(os.path.join(output_dir, f"breaths-k-{k}.csv"), index = False)