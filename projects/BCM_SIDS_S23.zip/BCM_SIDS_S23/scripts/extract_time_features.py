import os
import sys
import pandas as pd
from tqdm import tqdm
from boxsdk import Client

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from library.feature_engineering.time_dom_eng import compute_statistics
from library.data.BCMListDataLoader import BCMListDataLoader

# Set the data directory and the output directory
data_dir = "data"
type="breath"
output_dir = "processed_lists"

loader = BCMListDataLoader(data_dir=data_dir, verbose=True)


for file in (p := tqdm(loader)):
    mid, _ = file.split("_")
    # If the file already exists, skip it
    if os.path.exists(f"./{data_dir}/{output_dir}/{file}.csv"):
        continue

    try:
        p.set_description(f"Processing {file}")
        
        # Load the data
        data = loader.get(file)

        # Delete the file after it is iterated over
        if os.path.exists(f"{data_dir}/{file}.pkl.gz"):
            os.remove(f"{data_dir}/{file}.pkl.gz")

        # Delete the metadata file if it exists
        if os.path.exists(f"{data_dir}/{mid}_metadata.pkl"):
            os.remove(f"{data_dir}/{mid}_metadata.pkl")

        if data is None:
            continue

        # Get disk usage
        usage = sys.getsizeof(data)
        p.set_postfix({"usage": f"{usage / 1024 / 1024:.2f}mb"})

        # Get all of the phases
        data = data[data["sub_mode_block_id"].notnull()]

        # Calculate the features for each phase
        features = []
        for phase in data["sub_mode_block_id"].unique():
            gas = phase.split("-")[0].lower()

            # Get the data for this phase
            phase_data = data[data["sub_mode_block_id"] == phase].copy()

            # Calculate the features
            f = compute_statistics(gas, phase_data, exclude = [
                "time",
                "sub_mode_block_id",
                "sub_mode_block_start",
                "sub_mode_block_end",
                "observation_start",
                "observation_end",
                "observation_id",
                "sub_mode_block",
                "genotype",
                "weight",
                "mid"
            ])

            phase_features = pd.DataFrame.from_dict(f, orient="index").T

            phase_data = phase_data.reset_index(drop=True)
            phase_features = phase_features.reset_index(drop=True)

            # Join the columns and values of the features with the phase data ensuring that both values are kept
            phase_features = pd.concat([phase_data.head(1), phase_features], axis=1)
            
            features.append(phase_features)

        features = pd.concat(features)

        # Sort by sub_mode_block_start
        features = features.sort_values("sub_mode_block_start")

        # Add mid as first column
        features.insert(0, "mid", file)

        features.to_csv(f"./data/{output_dir}/{file}.csv", index=False)
    except Exception as e:
        print(f"Error processing {file}: {e}")

        # Refresh the oauth token
        p.set_description(f"Refreshing OAuth token")
        loader.refresh_oauth()