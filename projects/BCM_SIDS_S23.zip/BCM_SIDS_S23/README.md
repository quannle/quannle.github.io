# BCM_SIDS_S23
Rice D2K Project with the Baylor College of Medicine examining SIDS

## Project Background
Each day in the United States, about 10 apparently healthy infants die suddenly and unexpectedly. A full death scene investigation, autopsy, review of clinical history and appropriate laboratory testing fail to determine the cause of such deaths. The death of an infant for which physicians are unable to determine a medical cause is defined as Sudden Infant Death Syndrome (SIDS).

The Ray Lab (Baylor College of Medicine, Houston, TX) proposes that specific noradrenergic (NA) neurons play a crucial role in SIDS phenomenon. To test their hypothesis, the laboratory has used modern molecular biology techniques to develop genetic mouse models with a chemically mediated increase or decrease in NA neuron activity. To test if the engineered genotypes have differences in the SIDS sensibility, the Ray Lab has developed a unique robotic platform to record breathing and heart beating data to mimic SIDS conditions in neonate mice.

This Github software aims to process and visualize the mice respiratory and ECG data in order to:
 * classify mice based on their sensibility to SIDS 
 * predict SIDS putcome in individual mice 

## Repository Overview
This repository is for the Rice D2K Project Spring 2023 in collaboration with the Baylor College of Medicine's Ray Lab for examining Sudden Infant Death Syndrome in Mice Models.

The repository is structured as follows:
* __data__: Only contains a placeholder for security; see setting up data for further instructions
* __demos__: Contains notebooks to demo major modules and functions
* __library__: Contains all modules for the project
    * __box__: Contains the modules to access the box api
    * __data__: Modules to load data directly from box folder for processing
    * __denoise__: Modules to denoise raw ecg and breath data
    * __feature_engineering__: Modules for frequency and time domain feature engineering
    * __modeling__: Modules for survival and classification modeling
    * __viewers__: Modules to view common features for purpose of data exploration
    * __visualization__: Modules to visualize feature engineering
* __scripts__: Contains scripts to perform longer/batch io processes


## Getting Started
To begin running the project, you will need to ensure that you have condas installed.

To setup the environment, run the following command:
```
conda env create -f environment.yml
```
This will setup the environment with all the necessary packages.

To activate the environment, run the following command:
```
conda activate bcm
```


## Setting up the data
The data is not included in the respository for security reasons. To access the data, you will need access to the BCM_SIDS Data box folder which can be granted by the Ray Lab at Baylor College of Medicine or the Rice D2K instructors. 

You can download data from the Box folder to work with directly or utilize the data/ BCMDataLoader.py class to load data directly from the box. 

If you only want to run the demos on a few mice, you can download data for a few mice IDs and place it in the data directory. The BCMDataLoader.py was built for batch processing of any script on a large number of mice IDs.




## Running the project
If you are new to the project, the first thing you should look at is the Pipeline.ipynb notebook in the demos directory. This notebook will walk you through the entire pipeline of the finalized project to demonstrate step by step how to use the most important modules to reproduce our final results. 

Additionally we have created some demo notebooks that show how to use major functions/modules individually. Many of these demos expect data to be present in the data directory.




